<?php
	include("db_func.php");
	include("config.php");
?>