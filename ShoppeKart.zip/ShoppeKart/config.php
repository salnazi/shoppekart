<?php
	$snloginaccess = "loginaccess";
	$snInvestment = "investment";
	$snExpenses = "expenses";
	$snProfit = "profitpaidout";
	$snPurchase = "purchase";
	$snPurchaseData = "purchasedata";
	$snSales = "sales";
	$snStock = "stock";
	$snSalesReturn = "salesreturn";
	$snGrandSales = "grandsales";
	$sncompinfo = "compinfo";
?>