<!-- To the right -->
    <div class="pull-right hidden-xs">
     Inventory v.1.0.0 : Programmer : <a href="email-form.php">Salnazi</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2016 <a href="#"  target='_blank'>A2Z Marketing</a>.</strong> All rights reserved.
	
